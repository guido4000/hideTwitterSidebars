var elementLeft = document.getElementsByClassName("dashboard-left");
elementLeft[0].style.visibility = "hidden";

var elementRight = document.getElementsByClassName("dashboard-right");
elementRight[0].style.visibility = "hidden";
